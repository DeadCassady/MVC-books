-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: books_app
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `books_db`
--

DROP TABLE IF EXISTS `books_db`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books_db` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bookId` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `year` int NOT NULL,
  `pages` int NOT NULL,
  `views` int DEFAULT NULL,
  `clicks` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books_db`
--

LOCK TABLES `books_db` WRITE;
/*!40000 ALTER TABLE `books_db` DISABLE KEYS */;
INSERT INTO `books_db` VALUES (1,22,'СИ++ И КОМПЬЮТЕРНАЯ ГРАФИКА','Андрей Богуславский',2003,351,7,1),(2,23,'Программирование на языке Go!','Марк Саммерфильд',2016,550,10,1),(3,25,'Толковый словарь сетевых терминов и аббревиатур','М. Виллиамс',2002,368,3,0),(4,26,'Python for Data Analysis','Уэс Маккинни',2023,548,4,1),(5,27,'Thinking in Java (4th Edition)','Брюс Эккель',2006,1150,1,0),(6,29,'Introduction to Algorithms',' 	Томас Кормен, Чарльз Лейзерсон, Рональд Ривест, Клиффорд Штайн',2009,1312,0,0),(7,31,'JavaScript Pocket Reference','Дэвид Флэнаган',1998,89,0,0),(8,32,'Adaptive Code via C#: Class and Interface Design, Design Patterns, and SOLID Principles','Гэри Маклин Холл',2014,432,1,0),(9,33,'SQL: The Complete Referenc',' 	Джеймс Р. Грофф',2008,911,0,0),(10,34,'PHP and MySQL Web Development','Люк Веллинг',2015,592,0,0),(11,35,'Статистический анализ и визуализация данных с помощью R','Сергей Мастицкий',2022,496,0,0),(12,36,'Computer Coding for Kid','Джон Вудкок',2014,224,0,0),(13,37,'Exploring Arduino: Tools and Techniques for Engineering Wizardry','Джереми Блум',2002,385,0,0),(14,38,'Программирование микроконтроллеров для начинающих и не только','А. Белов',2003,351,1,0),(15,39,'The Internet of Things','Сэмюэл Грингард',2015,230,0,0),(16,40,'Sketching User Experiences: The Workbook','Saul Greenberg',2011,272,0,0),(17,41,'InDesign CS6','Александр Сераков',2012,576,0,0),(18,42,'Адаптивный дизайн. Делаем сайты для любых устройств','Тим Кедлек',2013,288,0,0),(19,43,'Android для разработчиков','Пол Дейтел, Харви Дейтел',2017,512,0,0),(20,44,'Clean Code: A Handbook of Agile Software Craftsmanship','Роберт Мартин',2008,464,0,0),(21,45,'Swift Pocket Reference: Programming for iOS and OS X','Энтони Грей',2015,236,0,0),(22,46,'NoSQL Distilled: A Brief Guide to the Emerging World of Polyglot Persistence','Мартин Фаулер, Прамодкумар Дж. Садаладж',2012,192,0,0),(23,47,'Head First Ruby','Джей Макгаврен',2016,539,0,0),(24,48,'Practical Vim','Дрю Нейл',2003,351,0,0);
/*!40000 ALTER TABLE `books_db` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-01 15:23:54
