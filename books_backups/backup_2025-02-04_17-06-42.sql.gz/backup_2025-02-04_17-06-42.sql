-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: books_app
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES (14,'А. Белов'),(17,'Александр Сераков'),(1,'Андрей Богуславский'),(5,'Брюс Эккель'),(8,'Гэри Маклин Холл'),(23,'Джей Макгаврен'),(9,'Джеймс Р. Грофф'),(13,'Джереми Блум'),(12,'Джон Вудкок'),(24,'Дрю Нейл'),(7,'Дэвид Флэнаган'),(10,'Люк Веллинг'),(3,'М. Виллиамс'),(2,'Марк Саммерфильд'),(22,'Мартин Фаулер, Прамодкумар Дж. Садаладж'),(19,'Пол Дейтел, Харви Дейтел'),(20,'Роберт Мартин'),(11,'Сергей Мастицкий'),(16,'Сол Гринберг'),(15,'Сэмюэл Грингард'),(18,'Тим Кедлек'),(6,'Томас Кормен, Чарльз Лейзерсон, Рональд Ривест, Клиффорд Штайн'),(4,'Уэс Маккинни'),(21,'Энтони Грей');
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `year` int NOT NULL,
  `pages` int NOT NULL,
  `views` int DEFAULT '0',
  `clicks` int DEFAULT '0',
  `deleted_at` datetime DEFAULT NULL,
  `cover_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,'СИ++ И КОМПЬЮТЕРНАЯ ГРАФИКА',2003,351,1,0,NULL,NULL),(2,'Программирование на языке Go!',2016,550,0,0,NULL,NULL),(3,'Толковый словарь сетевых терминов и аббревиатур',2002,368,0,0,NULL,NULL),(4,'Python for Data Analysis',2022,548,0,0,NULL,NULL),(5,'Thinking in Java (4th Edition)',2006,1150,0,0,NULL,NULL),(6,'Introduction to Algorithms',2009,1312,0,0,NULL,NULL),(7,'JavaScript Pocket Reference',1998,89,0,0,NULL,NULL),(8,'Adaptive Code via C#: Class and Interface Design, Design Patterns, and SOLID Principles',2014,432,0,0,NULL,NULL),(9,'SQL: The Complete Referenc',2003,911,1,1,NULL,NULL),(10,'PHP and MySQL Web Development',2015,592,0,0,NULL,NULL),(11,'Статистический анализ и визуализация данных с помощью R',2022,496,0,0,NULL,NULL),(12,'Computer Coding for Kids',2014,224,0,0,NULL,NULL),(13,'Exploring Arduino: Tools and Techniques for Engineering Wizardry',2002,385,0,0,NULL,NULL),(14,'Программирование микроконтроллеров для начинающих и не только',2016,352,0,0,NULL,NULL),(15,'The Internet of Things',2015,230,0,0,NULL,NULL),(16,'Sketching User Experiences: The Workbook',2011,272,0,0,NULL,NULL),(17,'InDesign CS6',2012,576,0,0,NULL,NULL),(18,'Адаптивный дизайн. Делаем сайты для любых устройств',2013,288,0,0,NULL,NULL),(19,'Android для разработчиков',2017,512,0,0,NULL,NULL),(20,'Clean Code: A Handbook of Agile Software Craftsmanship',2008,464,0,0,NULL,NULL),(21,'Swift Pocket Reference: Programming for iOS and OS X',2015,236,0,0,NULL,NULL),(22,'NoSQL Distilled: A Brief Guide to the Emerging World of Polyglot Persistence',2012,192,0,0,NULL,NULL),(23,'Head First Ruby',2016,539,0,0,NULL,NULL),(24,'Practical Vim',2003,351,0,0,NULL,NULL);
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books_authors`
--

DROP TABLE IF EXISTS `books_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books_authors` (
  `book_id` int NOT NULL,
  `author_id` int NOT NULL,
  PRIMARY KEY (`book_id`,`author_id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `books_authors_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `books_authors_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books_authors`
--

LOCK TABLES `books_authors` WRITE;
/*!40000 ALTER TABLE `books_authors` DISABLE KEYS */;
INSERT INTO `books_authors` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),(9,9),(10,10),(11,11),(12,12),(13,13),(14,14),(15,15),(16,16),(17,17),(18,18),(19,19),(20,20),(21,21),(22,22),(23,23),(24,24);
/*!40000 ALTER TABLE `books_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books_db`
--

DROP TABLE IF EXISTS `books_db`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books_db` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bookId` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `year` int NOT NULL,
  `pages` int NOT NULL,
  `views` int DEFAULT NULL,
  `clicks` int DEFAULT '0',
  `deleted_at` datetime DEFAULT NULL,
  `author2` varchar(255) DEFAULT NULL,
  `author3` varchar(255) DEFAULT NULL,
  `cover_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books_db`
--

LOCK TABLES `books_db` WRITE;
/*!40000 ALTER TABLE `books_db` DISABLE KEYS */;
INSERT INTO `books_db` VALUES (1,22,'СИ++ И КОМПЬЮТЕРНАЯ ГРАФИКА','Андрей Богуславский',2003,351,7,1,NULL,NULL,NULL,NULL),(2,23,'Программирование на языке Go!','Марк Саммерфильд',2016,550,13,2,NULL,NULL,NULL,NULL),(3,25,'Толковый словарь сетевых терминов и аббревиатур','М. Виллиамс',2002,368,5,0,NULL,NULL,NULL,NULL),(4,26,'Python for Data Analysis','Уэс Маккинни',2023,548,5,1,NULL,NULL,NULL,NULL),(5,27,'Thinking in Java (4th Edition)','Брюс Эккель',2006,1150,1,0,NULL,NULL,NULL,NULL),(6,29,'Introduction to Algorithms',' 	Томас Кормен, Чарльз Лейзерсон, Рональд Ривест, Клиффорд Штайн',2009,1312,0,0,NULL,NULL,NULL,NULL),(7,31,'JavaScript Pocket Reference','Дэвид Флэнаган',1998,89,0,0,NULL,NULL,NULL,NULL),(8,32,'Adaptive Code via C#: Class and Interface Design, Design Patterns, and SOLID Principles','Гэри Маклин Холл',2014,432,1,0,NULL,NULL,NULL,NULL),(9,33,'SQL: The Complete Referenc',' 	Джеймс Р. Грофф',2008,911,1,0,NULL,NULL,NULL,NULL),(10,34,'PHP and MySQL Web Development','Люк Веллинг',2015,592,0,0,NULL,NULL,NULL,NULL),(11,35,'Статистический анализ и визуализация данных с помощью R','Сергей Мастицкий',2022,496,0,0,NULL,NULL,NULL,NULL),(12,36,'Computer Coding for Kid','Джон Вудкок',2014,224,0,0,NULL,NULL,NULL,NULL),(13,37,'Exploring Arduino: Tools and Techniques for Engineering Wizardry','Джереми Блум',2002,385,0,0,NULL,NULL,NULL,NULL),(14,38,'Программирование микроконтроллеров для начинающих и не только','А. Белов',2003,351,1,0,NULL,NULL,NULL,NULL),(15,39,'The Internet of Things','Сэмюэл Грингард',2015,230,0,0,NULL,NULL,NULL,NULL),(16,40,'Sketching User Experiences: The Workbook','Saul Greenberg',2011,272,0,0,NULL,NULL,NULL,NULL),(17,41,'InDesign CS6','Александр Сераков',2012,576,0,0,NULL,NULL,NULL,NULL),(18,42,'Адаптивный дизайн. Делаем сайты для любых устройств','Тим Кедлек',2013,288,0,0,NULL,NULL,NULL,NULL),(19,43,'Android для разработчиков','Пол Дейтел, Харви Дейтел',2017,512,0,0,NULL,NULL,NULL,NULL),(20,44,'Clean Code: A Handbook of Agile Software Craftsmanship','Роберт Мартин',2008,464,0,0,NULL,NULL,NULL,NULL),(21,45,'Swift Pocket Reference: Programming for iOS and OS X','Энтони Грей',2015,236,0,0,NULL,NULL,NULL,NULL),(22,46,'NoSQL Distilled: A Brief Guide to the Emerging World of Polyglot Persistence','Мартин Фаулер, Прамодкумар Дж. Садаладж',2012,192,1,0,NULL,NULL,NULL,NULL),(23,47,'Head First Ruby','Джей Макгаврен',2016,539,0,0,NULL,NULL,NULL,NULL),(24,48,'Practical Vim','Дрю Нейл',2003,351,0,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `books_db` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration_history`
--

DROP TABLE IF EXISTS `migration_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migration_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `migration_name` varchar(255) NOT NULL,
  `executed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migration_name` (`migration_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_history`
--

LOCK TABLES `migration_history` WRITE;
/*!40000 ALTER TABLE `migration_history` DISABLE KEYS */;
INSERT INTO `migration_history` VALUES (1,'migrations/0001_initialize.sql','2025-02-04 19:52:50'),(2,'migrations/0002_convert_to_multiple_authors.sql','2025-02-04 19:52:50');
/*!40000 ALTER TABLE `migration_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-04 17:06:42
